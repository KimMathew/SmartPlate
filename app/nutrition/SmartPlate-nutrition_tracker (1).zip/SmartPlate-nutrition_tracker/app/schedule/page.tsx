"use client";

export default function SchedulePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Meal Scheduling</h1>
      <div className="bg-white rounded-xl shadow-md p-6">
        <p className="text-gray-500">
          Your meal scheduling calendar will appear here.
        </p>
      </div>
    </div>
  );
}
