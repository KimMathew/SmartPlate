import Forbidden from '@/components/ui/forbidden';

export default function ForbiddenPage() {
  return <Forbidden />;
}
